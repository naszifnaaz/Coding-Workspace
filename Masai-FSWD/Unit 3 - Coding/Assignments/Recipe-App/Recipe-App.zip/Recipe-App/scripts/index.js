import navbar from '../components/navbar.js';

let nav_container = document.getElementById("nav-container");
nav_container.innerHTML = navbar();




let navbar = () => {
  return `<nav>
    <div id="logo">
      <i class="fa-solid fa-language fa-2xl"></i>
      <span id="logo-text">TRANSLATER</span>
    </div>
  </nav>`;
};


export default navbar;